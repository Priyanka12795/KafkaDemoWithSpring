package com.demo.kafkademoproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkademoprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkademoprojectApplication.class, args);
	}

}
