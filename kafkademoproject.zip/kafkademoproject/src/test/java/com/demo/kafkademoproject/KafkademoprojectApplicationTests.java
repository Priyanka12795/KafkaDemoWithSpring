package com.demo.kafkademoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkademoprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
